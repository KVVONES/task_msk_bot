
📌 Инструкция по запуску Telegram Task Bot v2

1. Установи Python 3.10+ и pip
2. Установи библиотеку aiogram:
   python3 -m pip install aiogram

3. Запусти бота:
   python3 bot.py

📎 Команды:
• /task @username Текст задачи — классический способ
• @username Текст задачи — упрощённый способ (без /task)
• /mytasks — посмотреть свои задачи

‼️ Важно: в группах отключи Group Privacy через @BotFather:
/mybots → task_msk_bot → Bot Settings → Group Privacy → Turn OFF
